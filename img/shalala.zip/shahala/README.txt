
TITLE: 
Shahala - 100% Fully Responsive News Website Template

AUTHOR:
DESIGNED & DEVELOPED by FreeHTML5.co

Website: https://freehtml5.co/
Twitter: https://twitter.com/fh5co
Facebook: https://facebook.com/fh5co


CREDITS:

Bootstrap
http://getbootstrap.com/

Google Fonts
https://www.google.com/fonts/

jQuery
http://jquery.com/

Owl Carousel
http://www.owlcarousel.owlgraphic.com/

YU2FLV
http://otakod.es/yu2fvl

Demo Images:
http://unsplash.com

